# BE
BackEnd

파이썬 버전 3.11.9
파이썬 모듈 설치 : requirements.txt가 있는 폴더에서 pip install --no-cache-dir -r requirements.txt 명령어 입력


#실행 : app폴더에서 python main.py 명령어 입력

2024/05/01 명령어 변경
app 폴더에서 uvicorn main:app --reload --host 0.0.0.0 --port 8000 명령어 입력

웹 접근 url : localhost:8000
웹 api url : localhost:8000/docs
